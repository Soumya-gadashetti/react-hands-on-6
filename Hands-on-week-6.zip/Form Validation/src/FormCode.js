import React from 'react';
import {Field, reduxForm} from 'redux-form';
import {Checkbox} from '@material-ui/core';
import './formcode.css';

    const renderField = ({ input, label,label1, type, meta: { touched, error, warning } }) => (
        <div>
            <label className="control-label" >{label1}</label>
            <div>
                <input {...input} placeholder={label} type={type}   className="form-control" />
                {touched && ((error && <span className="text-danger">{error}</span>) || (warning && <span>{warning}</span>))}
             </div>
        </div>
    )

    const renderFieldtextbox = ({ input, label,label1, type, meta: { touched, error, warning } }) => (
        <div>
            <label className="control-label" >{label1}</label>
            <div>
                <textarea {...input} placeholder={label} type={type}   className="form-control" />
                {touched && ((error && <span className="text-danger">{error}</span>) || (warning && <span>{warning}</span>))}
             </div>
        </div>
    )

    const renderSelect=({input,label,type,meta:{touched,error,warning}})=>(
        <div>
            <select {...input} id="inputState" className="form-control">
                <option value>Select Location</option>
            </select>
            {touched && ((error && <span className="text-danger">{error}</span>) || (warning && <span>{warning}</span>))}
        </div>
    )

    const renderCheckbox=({input,label,type,meta:{touched,error,warning}})=>(
        <div>
            <Checkbox {...input} type={type}  className="form-check-input" />
            <label className="control-label" >{label}</label>
            {touched && ((error && <span className="text-danger">{error}</span>) || (warning && <span>{warning}</span>))}
        </div>
    );
  

    //Validation start
  
    const validate = values =>{
   
        const errors={}
        //Associate Name start
        if(!values.associateName){
          errors.associateName='Associate name required'
        }else if((values.associateName.length < 5)){
          errors.associateName ='Accepts Alphabets,space and min 5 characters'
        }else if(!/^[a-zA-Z ]*$/i.test(values.associateName)){
          errors.associateName='Please enter the Associate name and no special characters allowed'
        }
        //Associate Name end

        //Associate Id start
        if(!values.Associateid){
            errors.Associateid='Required'
        }else if((values.Associateid.length < 6)){
          errors.Associateid ='Invalid Associate Id'
        }else if(!/^[0-9\b]+$/i.test(values.Associateid)){
          errors.Associateid='Please enter Associate Id and accepts only numbers'
        }
        //Associate ID end

        //Project ID start
        if(!values.ProjectId){
            errors.ProjectId='Required'
        }else if((values.ProjectId.length < 12)){
            errors.ProjectId ='Invalid Project ID'
        }else if(!/[^0-9a-zA-Z]/i.test(values.ProjectId)){
            errors.ProjectId='Please enter the valid Project Id'
        }
        //Project Id end

        //Comments start
        if(!values.comments){
          errors.comments='Please Enter your comments'
        }
        //Comments end

        //File Upload start
        if(!values.image){
            errors.image='Please upload your Profile'
        }
        //File upload end

        //Location start
        if(!values.inputState){
            errors.inputState='Please select location'
        }
        //Location end

        //Checkbox start
        var count=0;

        if(values.html){
            count=count+1;
        }
        if(values.saas){
            count=count+1;
        }
        if(values.es){
            count=count+1;
        }
        if(values.bootstrap){
            count=count+1;
        }
        if(values.angular){
            count=count+1;
        }
        if(values.react){
            count=count+1;
        }
        if(values.veu){
            count=count+1;
        }
        if(values.typescript){
            count=count+1;
        }
        if(values.express){
            count=count+1;
        }
        if(values.node){
            count=count+1;
        }
        if(values.mango){
            count=count+1;
        }

        if(count < 5){
            errors.mango='Please select Min 5 Skills'
        }
        //Checkbox end

    return errors
    }
    //Validation end

    //Radio button Onshore start
    const selectHandler=()=>{
        const cities=['Chennai','Bangalore','Hyderabad','Pune','Kochi'];
        const select=document.getElementById('inputState');
            if(select.children.length >1){
                for(let i=select.children.length-1;i>0;i--){
                console.log(i,select.children[i]);
                select.removeChild(select.children[i]);
                }
            }
            cities.forEach((city)=>{
            const option=document.createElement('option');
            option.textContent=city;
            option.setAttribute('value',city);
            select.append(option);
            });
    }
    //Radio Button Onshore end
    
    //Radio Button Offshore start
    const selectHandler1=()=>{
        const noncity=['US','NON-US'];
        const select=document.getElementById('inputState');
        if(select.children.length >1){
            for(let i=select.children.length-1;i>0;i--){
                console.log(i,select.children[i]);
                select.removeChild(select.children[i]);
            }
        }
        noncity.forEach((city)=>{
        const option=document.createElement('option');
        option.textContent=city;
        option.setAttribute('value',city);
        select.append(option);
        });
    }
    //Radio button Offshore end

    //Checkbox start
    // const chkcontrol = (j) => {
    //     var total=0;
    //     var chk=document.getElementsByName('check');
    //     var ch1=chk.length;
    //     for(var i=0; i < ch1; i++){
    //         if(ch1[i].checked){
    //             total =total +1;
    //         }
    //         if(total < 5){
    //             alert("Please Select min 5 Skills") 
    //             ch1[j] = false ;
    //             return false;
    //         }
    //     }
    // }

    //Form Start
    let FormCode = props =>{
        const {handleSubmit, pristine, submitting,reset} = props;
        return(
            <form onSubmit={ handleSubmit} name="form1">
                {/* Associate Name */}
                <div className="form-group">
                    <Field name="associateName" component={renderField} min="5" max="30" label="AssociateName" />
                </div>

                {/* Associate Id */}
                <div className="form-group">
                    <Field name="Associateid" component={renderField} label="Associateid" />
                </div>

                {/* Project Id */}
                <div className="form-group">
                    <Field name="ProjectId" component={renderField} label="ProjectId" />
                </div>

                {/* Radio Button */}
                <div className="form-group">
                    <div className="form-check form-check-inline">
                        <input className="form-check-input" type="radio" name="inlineRadioOptions" id="inlineRadio1" value="onShore" onClick={selectHandler} />
                        <label className="form-check-label1" htmlFor="inlineRadio1">OnShore</label>
                    </div>
                    <div className="form-check form-check-inline">
                        <input className="form-check-input" type="radio" name="inlineRadioOptions" id="inlineRadio1" value="offShore" onClick={selectHandler1} />
                        <label className="form-check-label1" htmlFor="inlineRadio2">OffShore</label>
                    </div>
                  
                    <div className="form-group">
                        <Field name="inputState" component={renderSelect} />
                     </div>
                  
                </div>

                {/* Checkboxes */}
                <div className="form-group">
                    <div className="row"> 
                        <div className="col-md-3">
                            <div className="form-check">
                                <Field name="html"  component={renderCheckbox} label="HTML5,CSS3,JS"  type="checkbox"/>
                            </div>
                            <div>
                                <Field name="saas"   component={renderCheckbox} label="SAAS"  type="checkbox"/>
                            </div>
                            <div>
                                <Field name="es"  component={renderCheckbox} label="ES5,ES6,ES7"  type="checkbox"/>
                            </div>
                            <div>
                                <Field name="bootstrap"  component={renderCheckbox} label="Bootstrap 4"  type="checkbox"/>
                            </div>
                            
                        </div>
                        
                        <div className="col-md-3">
                            <div className="form-check">
                                <Field name="angular"   component={renderCheckbox} label="Angular 8"  type="checkbox"/>
                            </div>
                            <div>
                                <Field name="react"  component={renderCheckbox} label="React JS"  type="checkbox"/>
                            </div>
                            <div>
                                <Field name="veu"   component={renderCheckbox} label="Veu JS"  type="checkbox"/>
                            </div>
                            <div>
                                <Field name="typescript"   component={renderCheckbox} label="TypeScript"  type="checkbox"/>
                            </div>
                        </div>

                        <div className="col-md-3">
                            <div className="form-check">
                                <Field name="express"   component={renderCheckbox} label="Express JS"  type="checkbox"/>
                            </div>
                            <div>
                                <Field name="node"   component={renderCheckbox} label="Node JS"  type="checkbox"/>
                            </div>
                            <div>
                                <Field name="mango"  component={renderCheckbox} label="Mango DB"  type="checkbox"/>
                            </div>
                        </div>
                    </div>
                </div>
                
                {/* Profile Upload */}
                <div className="form-group">
                    <Field name="image" type="file" component={renderField} label="Upload" label1="Upload Profile"/>
                </div>

                {/* Comments */}
                <div className="form-group">
                    <Field name="comments" type="textarea" component={renderFieldtextbox} multiLine={true} rows={3} label="comments" />
                </div>

                {/* Buttons */}
                <div className="form-group">
                    <button type="submit" disabled={pristine || submitting} className="btn btn-primary">Submit</button>
                    <button type="button" disabled={pristine || submitting} onClick={reset} className="btn btn-danger">Clear Values</button>
                </div>
            </form>
        )
    }

    FormCode = reduxForm({
        form:'contact',
        validate
    })(FormCode)
    export default FormCode;